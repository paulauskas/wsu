﻿Imports System.Security
Imports System.IO
Imports System.Diagnostics
Public Class frmWSU
    Function ConvertToSecureString(ByVal str As String)
        'converts string to secure string
        Dim password As New SecureString
        For Each c As Char In str.ToCharArray
            password.AppendChar(c)
        Next
        'Returns new secure string
        Return password
    End Function

    Sub headShake()
        Dim moveCounter As Integer
        For moveCounter = 1 To 5
            Me.Left = Me.Left - 20
            Me.Left = Me.Left + 40
            Me.Left = Me.Left - 20
        Next
    End Sub
    Public args() As String
    Public adminAcct As String
    Public failedAttemts As Integer
    Public cpuPri As ProcessPriorityClass

    Private Sub frmWinSu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'if no arg is passed, exit wsu
        args = Environment.GetCommandLineArgs
        If args Is Nothing Or args.Length < 2 Then End
        Try
            'Gets admin acct from configuration file
            Dim file As New FileStream("C:\wsu.conf", FileMode.Open, FileAccess.Read)
            Dim fileReader As New StreamReader(file)
            adminAcct = fileReader.ReadLine
            'If the file is blank, do nothing
            If adminAcct = "" Then End
            'Closes filestream and streamreader
            fileReader.Close()
            file.Close()
            lblAcct.Text = "Enter the password for " & adminAcct & " to perform administrative tasks"
            cpuPri = ProcessPriorityClass.Normal
        Catch
            End
        End Try
        If args.Length = 4 Then
            If args(2) = "-p" Then
                'Get and set cpu priority argument
                Select Case args(3)
                    Case "1"
                        cpuPri = ProcessPriorityClass.BelowNormal
                    Case "2"
                        cpuPri = ProcessPriorityClass.Normal
                    Case "3"
                        cpuPri = ProcessPriorityClass.AboveNormal
                    Case "4"
                        cpuPri = ProcessPriorityClass.High
                    Case "5"
                        cpuPri = ProcessPriorityClass.RealTime
                End Select
            Else
                cpuPri = ProcessPriorityClass.Normal
            End If
        End If
    End Sub

    Sub StartProc()
        Try
            'instantiates new process from the path read from config file
            'Process is started as user adminAcct with password from txtPasswd
            Dim proc As New Process
            proc.StartInfo.FileName = args(1)
            proc.StartInfo.UseShellExecute = False
            proc.StartInfo.UserName = adminAcct
            proc.StartInfo.Password = ConvertToSecureString(txtPasswd.Text)
            proc.Start()
            proc.PriorityClass = cpuPri
        Catch ex As Exception
            ' displays message if an error occurs
            lblAcct.Text = ex.Message
            'if error is from incorrect logon info, then start over
            'if 3 bad logon attempts > Quit
            If Err.Number = 5 Then
                headShake()
                txtPasswd.Text = ""
                failedAttemts += 1
                lblAttempts.Text = failedAttemts & " Failed Attempts"
                If failedAttemts < 3 Then
                    Exit Sub
                Else
                    End
                End If
            End If
        End Try
        End
    End Sub

    Private Sub cmdOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        'Executes StartProc() routine
        StartProc()
    End Sub

    Private Sub txtPasswd_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtPasswd.KeyPress
        'Executes StartProc() routine if enter key (chr(13)) is pressed
        If e.KeyChar = Chr(13) Then
            'e.Handled stops the proram from making the really annoying _
            'error alert noise when you press the enter key on a single _
            'line textbox
            e.Handled = True
            StartProc()
        End If
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        End
    End Sub

    Private Sub cmdAbout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdAbout.Click
        MsgBox("wsuversion 2008.05-Beta2.2" & vbCrLf & "Written by Matt Paulauskas")
    End Sub
End Class
